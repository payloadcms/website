//
//  ViewController.swift
//  NicepayAppSample
//
//  Created by xoghzone on 2019/11/27.
//  Copyright © 2019 Nicepayment. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

