"""Max number of recent conversation steps to include in LLM prompt"""

LLM_HISTORY_LIMIT = 20
