---
title: "Plugin API | 토스플레이스 연동 가이드"
source: "https://docs.tossplace.com/reference/plugin-sdk/pos/plugin.html"
author:
published:
created: 2025-11-29
description: "토스 프론트, 토스 POS 연동 개발을 위한 가이드입니다"
tags:
  - "clippings"
---
[Skip to content](https://docs.tossplace.com/reference/plugin-sdk/pos/#VPContent)

## Plugin API

Toss POS의 정보를 조회하거나 graceful shutdown을 위해 업데이트 전 콜백이 실행됩니다

## Methods

### getPluginInfo

플러그인의 기본적인 정보를 조회합니다