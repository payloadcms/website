---
title: "UI API | 토스플레이스 연동 가이드"
source: "https://docs.tossplace.com/reference/plugin-sdk/pos/ui.html"
author:
published:
created: 2025-11-29
description: "토스 프론트, 토스 POS 연동 개발을 위한 가이드입니다"
tags:
  - "clippings"
---
[Skip to content](https://docs.tossplace.com/reference/plugin-sdk/pos/#VPContent)

## UI API

POS 플러그인에서 제공하는 UI 컴포넌트 API입니다. 현재는 팝업 UI만 제공하며, 추후 다양한 UI 컴포넌트가 추가될 예정입니다.

## Types

### Barcode

바코드 스캔을 위한 UI 타입입니다.

## Methods

### openPopup

팝업 UI를 표시합니다.