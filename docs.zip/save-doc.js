#!/usr/bin/env node
/**
 * CareOn 문서 자동 저장 스크립트
 * 사용법: node save-doc.js <type> <filename> [url]
 * 
 * Types:
 *   api-docs    - API 문서
 *   research    - 리서치/분석 문서
 *   guides      - 가이드/튜토리얼
 *   references  - 참고 자료
 *   chat-logs   - 채팅 로그
 */

const fs = require('fs');
const path = require('path');
const https = require('https');
const http = require('http');

const BASE_DIR = '/data/data/com.termux/files/home/storage/documents';

const VALID_TYPES = ['api-docs', 'research', 'guides', 'references', 'chat-logs'];

function sanitizeFilename(name) {
  return name.replace(/[^a-zA-Z0-9가-힣_\-\.]/g, '_');
}

function getTimestamp() {
  const now = new Date();
  return now.toISOString().split('T')[0];
}

function saveFromStdin(type, filename) {
  let content = '';
  process.stdin.setEncoding('utf8');
  process.stdin.on('data', chunk => content += chunk);
  process.stdin.on('end', () => {
    const filepath = path.join(BASE_DIR, type, `${getTimestamp()}_${sanitizeFilename(filename)}`);
    fs.writeFileSync(filepath, content, 'utf8');
    console.log(`✓ Saved: ${filepath}`);
  });
}

function downloadAndSave(type, filename, url) {
  const protocol = url.startsWith('https') ? https : http;
  const filepath = path.join(BASE_DIR, type, `${getTimestamp()}_${sanitizeFilename(filename)}`);
  
  protocol.get(url, (res) => {
    if (res.statusCode === 301 || res.statusCode === 302) {
      downloadAndSave(type, filename, res.headers.location);
      return;
    }
    
    let data = '';
    res.on('data', chunk => data += chunk);
    res.on('end', () => {
      fs.writeFileSync(filepath, data, 'utf8');
      console.log(`✓ Downloaded and saved: ${filepath}`);
    });
  }).on('error', err => {
    console.error(`✗ Error: ${err.message}`);
  });
}

// Main
const args = process.argv.slice(2);

if (args.length < 2) {
  console.log('Usage: node save-doc.js <type> <filename> [url]');
  console.log('       echo "content" | node save-doc.js <type> <filename>');
  console.log('\nTypes:', VALID_TYPES.join(', '));
  process.exit(1);
}

const [type, filename, url] = args;

if (!VALID_TYPES.includes(type)) {
  console.error(`✗ Invalid type: ${type}`);
  console.log('Valid types:', VALID_TYPES.join(', '));
  process.exit(1);
}

if (url) {
  downloadAndSave(type, filename, url);
} else {
  saveFromStdin(type, filename);
}
